﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Covid.Dominio;
using Covid.Dominio.Contratos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Covid.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PerguntasController : ControllerBase
    {

        private readonly IRepositorio<Pergunta> _repositorioPergunta;

        public PerguntasController(IRepositorio<Pergunta> repositorioPergunta)
        {
            _repositorioPergunta = repositorioPergunta;
        }

        [HttpGet("/api/perguntas")]
        public IActionResult GetQuestions()
        {
            return Ok(_repositorioPergunta.GetAll());
        }
    }
}
