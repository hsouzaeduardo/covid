﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Covid.Infra.Migrations
{
    public partial class PrimeiraMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Functionarios",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    DataInclusao = table.Column<DateTime>(nullable: false),
                    DataAlteracao = table.Column<DateTime>(nullable: false),
                    Nome = table.Column<string>(nullable: true),
                    Cpf = table.Column<string>(nullable: true),
                    DtNascimento = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Functionarios", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Perguntas",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    DataInclusao = table.Column<DateTime>(nullable: false),
                    DataAlteracao = table.Column<DateTime>(nullable: false),
                    Questap = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Perguntas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Prontuarios",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    DataInclusao = table.Column<DateTime>(nullable: false),
                    DataAlteracao = table.Column<DateTime>(nullable: false),
                    FunctionarioId = table.Column<Guid>(nullable: true),
                    Temperatura = table.Column<decimal>(nullable: true),
                    Estado = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Prontuarios", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Prontuarios_Functionarios_FunctionarioId",
                        column: x => x.FunctionarioId,
                        principalTable: "Functionarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Respostas",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    DataInclusao = table.Column<DateTime>(nullable: false),
                    DataAlteracao = table.Column<DateTime>(nullable: false),
                    Resp = table.Column<string>(nullable: true),
                    Peso = table.Column<int>(nullable: false),
                    IdPerguta = table.Column<Guid>(nullable: false),
                    PerguntaId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Respostas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Respostas_Perguntas_PerguntaId",
                        column: x => x.PerguntaId,
                        principalTable: "Perguntas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProntuarioPergunta",
                columns: table => new
                {
                    IdProntuario = table.Column<Guid>(nullable: false),
                    IdQuestao = table.Column<Guid>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProntuarioPergunta", x => new { x.IdProntuario, x.IdQuestao });
                    table.ForeignKey(
                        name: "FK_ProntuarioPergunta_Prontuarios_IdProntuario",
                        column: x => x.IdProntuario,
                        principalTable: "Prontuarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProntuarioPergunta_Perguntas_IdQuestao",
                        column: x => x.IdQuestao,
                        principalTable: "Perguntas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PerguntaResposta",
                columns: table => new
                {
                    IdPergunta = table.Column<Guid>(nullable: false),
                    IdResposta = table.Column<Guid>(nullable: false),
                    Id = table.Column<Guid>(nullable: false),
                    DataInclusao = table.Column<DateTime>(nullable: false),
                    DataAlteracao = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PerguntaResposta", x => new { x.IdPergunta, x.IdResposta });
                    table.ForeignKey(
                        name: "FK_PerguntaResposta_Perguntas_IdPergunta",
                        column: x => x.IdPergunta,
                        principalTable: "Perguntas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PerguntaResposta_Respostas_IdResposta",
                        column: x => x.IdResposta,
                        principalTable: "Respostas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PerguntaResposta_IdResposta",
                table: "PerguntaResposta",
                column: "IdResposta");

            migrationBuilder.CreateIndex(
                name: "IX_ProntuarioPergunta_IdQuestao",
                table: "ProntuarioPergunta",
                column: "IdQuestao");

            migrationBuilder.CreateIndex(
                name: "IX_Prontuarios_FunctionarioId",
                table: "Prontuarios",
                column: "FunctionarioId");

            migrationBuilder.CreateIndex(
                name: "IX_Respostas_PerguntaId",
                table: "Respostas",
                column: "PerguntaId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PerguntaResposta");

            migrationBuilder.DropTable(
                name: "ProntuarioPergunta");

            migrationBuilder.DropTable(
                name: "Respostas");

            migrationBuilder.DropTable(
                name: "Prontuarios");

            migrationBuilder.DropTable(
                name: "Perguntas");

            migrationBuilder.DropTable(
                name: "Functionarios");
        }
    }
}
