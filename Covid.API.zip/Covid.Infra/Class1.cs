﻿using System;

namespace Covid.Infra
{
    public class Class1
    {
    }
}
