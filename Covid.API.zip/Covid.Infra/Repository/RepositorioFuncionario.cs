﻿using Covid.Dominio;
using Covid.Dominio.Contratos;
using Covid.Infra.Contexto;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Covid.Infra.Repositorios
{
    public class RepositorioFuncionario : Repositorio<Functionario>, IRepositorioFuncionario
    {
        public RepositorioFuncionario(ContextoEF dbContext):base(dbContext)
        {

        }
        public Functionario GetEmployeeByDocument(string cpf)
        {
            return _tables.FirstOrDefault(x => x.Cpf.Equals(cpf));
        }
    }
}
