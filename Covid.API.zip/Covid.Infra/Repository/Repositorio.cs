﻿using Covid.Dominio;
using Covid.Dominio.Contratos;
using Covid.Infra.Contexto;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Covid.Infra.Repositorios
{
    public class Repositorio<T> : IRepositorio<T> where T: BaseClass
    {
        private readonly ContextoEF _ctx;
        internal readonly DbSet<T> _tables;

        public Repositorio(ContextoEF dbContext)
        {
            _ctx = dbContext;
            _tables = dbContext.Set<T>();
        }
        public void Delete(T entity)
        {
            _tables.Remove(entity);
        }

        public IEnumerable<T> GetAllByWhere(Expression<Func<T, bool>> filtro)
        {
            return _tables.Where(filtro);
        }

        public T GetById(Guid id)
        {
            return _tables.Find(id);
        }

        public int GetCount()
        {
            return _tables.Count();
        }

        public void Save(T entity)
        {
            _tables.Add(entity);
            _ctx.SaveChanges();
        }

        public void Update(T entity)
        {
            _tables.Update(entity);
            _ctx.SaveChanges();
        }

        public IEnumerable<T> GetAll()
        {
            return _tables.ToList();
        }
    }
}
