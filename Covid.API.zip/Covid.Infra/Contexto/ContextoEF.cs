﻿using Covid.Dominio;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Text;

namespace Covid.Infra.Contexto
{
    public class ContextoEF : DbContext
    {
        public ContextoEF(DbContextOptions<ContextoEF> options):base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProntuarioPergunta>().HasKey(pk => new { pk.IdProntuario, pk.IdQuestao });
            modelBuilder.Entity<ProntuarioPergunta>().HasOne(fk => fk.Prontuario).WithMany(fk => fk.Questoes).HasForeignKey(x => x.IdProntuario);
            modelBuilder.Entity<ProntuarioPergunta>().HasOne(fk => fk.Questao).WithMany(fk => fk.Prontuarios).HasForeignKey(x => x.IdQuestao);

            modelBuilder.Entity<PerguntaResposta>().HasKey(pk => new { pk.IdPergunta, pk.IdResposta});
            modelBuilder.Entity<PerguntaResposta>().HasOne(fk => fk.Resposta).WithMany(fk => fk.PerguntaResposta).HasForeignKey(x => x.IdResposta) ;
            modelBuilder.Entity<PerguntaResposta>().HasOne(fk => fk.Pergunta).WithMany(fk => fk.PerguntaResposta).HasForeignKey(x => x.IdPergunta);
        }

        public DbSet<Pergunta> Perguntas { get; set; }
        public DbSet<Functionario> Functionarios { get; set; }
        public DbSet<Resposta> Respostas { get; set; }
        public DbSet<Prontuario> Prontuarios { get; set; }
    }
}
