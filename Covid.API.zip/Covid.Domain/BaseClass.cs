﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Covid.Dominio
{
    
    public abstract class BaseClass
    {
        public BaseClass()
        {
            Id = Guid.NewGuid();

            DataInclusao = DateTime.Now;
        }

        public BaseClass(string log)
        {
            
        }

        public Guid Id { get; set; }
        public DateTime DataInclusao { get; set; }
        public DateTime DataAlteracao { get; set; }
    }
}
