﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Covid.Dominio
{
    public class Pergunta :BaseClass
    {
        public string Questap { get; set; }
        public List<Resposta> Respostas { get; set; }
        public List<ProntuarioPergunta> Prontuarios { get; set; }
        public List<PerguntaResposta> PerguntaResposta { get; set; }
    }
}
