﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Covid.Dominio;
namespace Covid.Dominio.Contratos
{
    public interface IRepositorioFuncionario: IRepositorio<Functionario>
    {
        Functionario GetEmployeeByDocument(string cpf);
    }
}
