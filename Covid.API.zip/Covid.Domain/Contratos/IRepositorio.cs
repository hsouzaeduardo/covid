﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Covid.Dominio.Contratos
{
    //Repository Pattern
    //UnitOfWork
    public interface IRepositorio<T> where T: BaseClass
    {

        T GetById(Guid id);
        IEnumerable<T> GetAllByWhere(Expression<Func<T, bool>> filtro);
        IEnumerable<T> GetAll();
        void Save(T entity);
        void Delete(T entity);
        void Update(T entity);
        int GetCount();
    }
}
