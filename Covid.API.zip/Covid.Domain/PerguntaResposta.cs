﻿using System;

namespace Covid.Dominio
{
    public class PerguntaResposta : BaseClass
    {
        public Guid IdPergunta { get; set; }
        public Guid IdResposta { get; set; }
        public Pergunta Pergunta { get; set; }
        public Resposta Resposta { get; set; }
    }
}