﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Covid.Dominio
{
    public class Prontuario :BaseClass
    {
        public Functionario Functionario { get; set; }

        public List<ProntuarioPergunta> Questoes { get; set; }

        public decimal? Temperatura { get; set; }

        public bool Estado { get; set; }
    }

    public class ProntuarioPergunta {

        public Guid IdProntuario { get; set; }
        public Guid IdQuestao { get; set; }
        public Pergunta Questao { get; set; }
        public Prontuario Prontuario { get; set; }

    }
}
