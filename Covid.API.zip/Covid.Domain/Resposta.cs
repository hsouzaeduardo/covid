﻿using System;
using System.Collections.Generic;

namespace Covid.Dominio
{
    public class Resposta : BaseClass
    {
        public string Resp { get; set; }
        public int Peso { get; set; }
        public Guid IdPerguta { get; set; }
        public List<PerguntaResposta> PerguntaResposta { get; set; }
    }
}