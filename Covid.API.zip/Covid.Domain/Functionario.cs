﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Covid.Dominio
{
    public class Functionario : BaseClass
    {
        
        public Functionario(string nome, string cpf, DateTime dtNascimento)
        {
            this.Nome = nome;
            this.Cpf = cpf;
            this.DtNascimento = dtNascimento;
        }

        public string Nome { get; private set; }
        public string Cpf { get; private set; }
        public DateTime DtNascimento { get; private set; }
        public int Idade
        {
            get
            {
                var idade = DateTime.Now.Year - DtNascimento.Year;

                return (DateTime.Now.DayOfYear < DtNascimento.DayOfYear) ? --idade : idade;
            }
        }
        
        //public int CompareTo(Functionario other)
        //{
        //    if(this.DtNascimento == other.DtNascimento)
        //    {
        //        return this.Nome.CompareTo(other.Nome);
        //    }

        //    return other.Nome.CompareTo(this.Nome);
        //}
    }

    
}
